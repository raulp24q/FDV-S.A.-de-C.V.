# Diseño de Mueble LED

Este proyecto incluye el diseño de un mueble iluminado con tiras LED, combinando carpintería y electrónica básica.
