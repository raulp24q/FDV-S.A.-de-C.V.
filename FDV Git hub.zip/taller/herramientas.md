# Herramientas del Taller

Listado de herramientas disponibles:

- Sierra de inglete
- Sierra circular
- Pulidor
- Taladro
- Router o fresadora
- Máquina de soldar
- Cautín, estaño y pasta para electrónica
